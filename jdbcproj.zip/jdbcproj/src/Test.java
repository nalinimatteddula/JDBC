import com.mtc.bo.Product;
import com.mtc.bo.*;
import java.util.*;
import java.sql.*;
import java.util.ArrayList;
public class Test {
	
	private static final String INSERT_QUERY = "insert into test.product(id,name,price,description,quantity) values(?,?,?,?,?)";
	
	public static final String SELECT_QUERY_BY_ID = "select * from test.product where id=?";
	
	public static final String SELECT_QUERY = "Select * from test.product";
	
	public static List<Product> findAllProducts(){
		
		ArrayList<Product> productList = new ArrayList<Product>();
		
		try (
                // connection url
      Connection connection1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","sailaja3!")){

		Statement statement = connection1.createStatement();
		
		statement.executeQuery(SELECT_QUERY);
		
		ResultSet resultSet = statement.executeQuery(SELECT_QUERY);
		
		while(resultSet.next()){
			
			Product product = new Product();
			
			product.setId(resultSet.getInt("Id"));
			product.setName(resultSet.getString("Name"));
			product.setPrice(resultSet.getFloat("Price"));
			product.setDescription(resultSet.getString("Description"));
			product.setQuantity(resultSet.getInt("Quantity"));
			
			productList.add(product);
			
		
		}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		} return productList;
			
	}
	
	public static Product findById(int id) {
		
		Product product = null;
		
		try (
			                                                     // connection url
			Connection connection1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","sailaja3!")){
			
			PreparedStatement preparedStatement = connection1.prepareStatement(SELECT_QUERY);
		    preparedStatement.setInt(1, id);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
			
				product = new Product();
				
				product.setId(resultSet.getInt("Id"));
				product.setName(resultSet.getString("Name"));
				product.setPrice(resultSet.getFloat("Price"));
				product.setDescription(resultSet.getString("Description"));
				product.setQuantity(resultSet.getInt("Quantity"));
				
				return product;
				
				
			}
	}catch (Exception e) {
		e.printStackTrace();
	}
		return product;
	}
	
	public static void add(Product product) throws SQLException {
		
		Connection connection = null;
		try {
			 //Step 1: Establish connection with mysql Database server
			                                                     // connection url
			Connection connection1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","sailaja3!");
			
			// step 2 : Create PreparedStatement Object
			//PreparedStatement object is used to execute a query
			PreparedStatement preparedStatement = connection1.prepareStatement(INSERT_QUERY);
		    
			//Step 3: assign values to the bind parameters
			preparedStatement.setInt(1,product.getId());
			preparedStatement.setString(2,product.getName());
			preparedStatement.setFloat(3,product.getPrice());
			preparedStatement.setString(4,product.getDescription());
			preparedStatement.setInt(5,product.getQuantity());
		
			//Step 4: execute the query using preparedstatement
			int noOfRows = preparedStatement.executeUpdate();
		
			if(noOfRows ==1) {
				System.out.println("Record added successfully");
				
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			//Step 6 :Close the connection
			connection.close();
		}
	}

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		List<Product> products = findAllProducts();
		
		for(Product product : products) {
			System.out.println(product);
		}
		
//		Product product = findById(1);
//		
//		System.out.println(product);

//		Product product = new Product(15,"Desk20",50,"Desk",100);
//		add(product);
}

}
